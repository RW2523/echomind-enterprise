EchoMind — QASC 2026 camera-ready (Springer LNEE / svproc, single column, A4, 10pt)

Files:
  main.tex     — manuscript source
  svproc.cls   — Springer proceedings document class (v1.3, 20-JUL-2016)
  fig1_v2.pdf  — Figure 1 (vector)

Build (TeX Live 2023+):
  pdflatex main
  pdflatex main        # second pass resolves cross-references

Notes:
  - References are inline (thebibliography); no .bib / bibtex step needed.
  - A4 page size is forced after \mainmatter.
