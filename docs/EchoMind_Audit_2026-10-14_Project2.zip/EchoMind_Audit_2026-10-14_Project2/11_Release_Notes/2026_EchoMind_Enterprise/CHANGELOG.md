# Changelog

All notable changes to EchoMind Enterprise are recorded here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project uses
[semantic versioning](https://semver.org/spec/v2.0.0.html).

This file is generated from the git history by `scripts/gen_changelog.sh`; do
not edit it by hand. Versions are cut by `scripts/release.sh`, which tags the
source revision that each released image is built from (ISO 9001:2015, 8.5.2).
Versions 1.0.0 to 1.3.0 are retrospective baselines: the 2026 increments, identified
on 2026-10-12 from this history and tagged on the last commit of each increment.
They were not released as numbered versions at the time; release records start at 1.4.0.

History covered: 2026-02-05 to 2026-10-12.

## Unreleased

### Documentation

- **qms**: evidence package after the AR-2026-003 approval (snapshot 2026-10-12 @ 98531cc) (`1c41b36`)
- **qms**: Excel registers EM26-19…22 approved (AR-2026-003) (`98531cc`)
- **qms**: evidence package with the Excel registers EM26-19…22 (snapshot 2026-10-11 @ 33273a2) (`76505d8`)
- **qms**: Excel registers EM26-19…22 — review log, functional and non-functional requirements, roadmap (2025 → 2027) (`33273a2`)
- **qms**: evidence package rebuilt after the rev 1.1 approval (snapshot 2026-10-10 @ 698e0ce) (`9ded4da`)
- **qms**: revision 1.1 approved (AR-2026-002) — review and NFR evidence signed off (`698e0ce`)
- **qms**: evidence package rebuilt with the client and design review history (snapshot 2026-10-10 @ 2e18a33) (`788b0cd`)
- **qms**: client and design reviews 2025–2026 in the review log (EM26-18 rev 1.1) (`2e18a33`)
- **qms**: ISO 9001 evidence package rebuilt after approval (snapshot 2026-10-07 @ 3b05278) (`95782e4`)
- **qms**: approve the full QMS set (AR-2026-001) and bring every document up to date (`3b05278`)
- **qms**: closure evidence for 2025 findings #6 (NFRs) and #7 (review actions) (`ac600ae`)
- **qms**: ISO 9001 evidence package as a single download (snapshot 2026-10-07) (`24ccb48`)
- **qms**: NC-2026-010 closed — CI proven to fail on a broken test; first external login check passed (`b2a1658`)
- **qms**: project board evidence — 65 tracked tickets replace the 2025 Jira screens (`6c24efe`)
- **qms**: current GitHub evidence — v1.4.1 tag and the defect-fix commit (`7bdcb94`)
- **qms**: refer to the 2025 pilot customer generically in the evidence pack (`ba80d9f`)
- **qms**: point test records at the per-run execution folders (`eb8ace2`)

### Other changes

- ci: run the public login gate check when its definition changes (`ee26cfd`)
- qms: corrective actions for NC-2026-008/009/010/016 — CI, external login check, eval pre-flight (`f3aca50`)

## [1.4.1] - 2026-10-06

### Fixed

- **audit**: attribute activity to the caller before the request runs (`3feb5db`)
- correct the four defects found by the 2026-10-06 acceptance tests (`e0ed4d0`)
- **frontend**: type fadeUp as framer-motion Variants (`736ea61`)

### Documentation

- **changelog**: regenerate for v1.4.1 (`f1b8445`)
- **qms**: 2026 EchoMind ISO 9001 evidence pack; raise NC-2026-011..015 (`bd44ade`)
- **qms**: record 2026-10-06 deployment — login restored, v1.4.0 code live, log rotation applied (`1d7f154`)
- **qms**: correct audit-pack claims against the running system; raise NC-2026-009/010 (`855bd80`)

### Other changes

- chore(release): v1.4.1 (`6ac7021`)
- test: update 5 stale tests to match current behaviour (`5ddf8a6`)

## [1.4.0] - 2026-09-22

### Added

- **build**: release identification, off-host backup scheduling, pinned NeMo (`51fd3bc`)
- **voice**: speculative replies, LLM tool routing, dynamic hold phrases, GPU final STT (`ff29843`)
- **transcript,voice,chat**: cleaner utterances, gated checks, enterprise voice tone, focused UI (`15f3c96`)

### Fixed

- **transcript**: render live speech as continuous text, not per-chunk sentences (`c2a6ed5`)

### Documentation

- **changelog**: regenerate for v1.4.0 (`eaa7b1a`)
- **qms**: October surveillance audit pack for the EchoMind Product area (`4a43773`)
- **qms**: ISO 9001:2015 quality management system, repo tidy-up, data backup (`9efb134`)

### Other changes

- chore(release): v1.4.0 (`b0ba848`)

## [1.3.0] - 2026-08-16

### Added

- **silent-assistant**: sentence-level live checks with quoted proof, record pull, scenarios (`7f2658a`)
- **voice**: loop provenance tags and ablation switch for paper eval (`5ce8bbe`)
- **security**: enable auth; sanitize citation artifacts; reserve 'default' tenant (`9810e98`)
- **rag**: tier-2 quality fixes — early sources, fail-closed, follow-up context (`b6aa963`)
- **eval**: voice end-to-end test — synthetic speech through the live WS loop (`8e6d984`)
- **llm**: port chat to Qwen3-30B-A3B NVFP4 on TensorRT-LLM (driver fix confirmed) (`80375c6`)
- **eval**: golden-question evaluation harness for the RAG + conversation stack (`12f7219`)
- **rag**: conversational intelligence, honest citations, persona quality overhaul (`343117f`)

### Fixed

- **rag**: overhaul ingestion, embeddings, scoring end to end (`7e582e1`)
- **chat**: kill repetition loops, right-size answers, harden personas (`149a1b6`)
- **voice**: sentence-aligned TTS cadence, pipelined synthesis, smooth playback (`1d1e3aa`)
- **rag**: enforce namespace predicate on sparse transcript path (`4e27109`)
- **rag**: gate BookRAG behind RAG_ENABLE_BOOKRAG (default off) — it measured worse (`2decb99`)
- **rag**: stop silent content loss, unblock BookRAG, guard reasoning leaks (`7b04eb9`)
- **voice**: pass VOICE_AUTH_SECRET (not AUTH_SECRET) so the WS gate actually works (`73f0b4f`)
- **scripts**: await delete_document in re-ingest; add stale-PDF dedupe (`febfc5f`)
- **rag**: unblock BookRAG + stop silent content loss in PDF ingestion (`4a8402e`)
- **tts**: /api/transcribe/speak returned null audio — wrong voice port (`558eaae`)
- **voice**: eliminate TTS gaps — trim phrase silence, controlled pauses, edge-only fades (`31b7786`)
- **rag**: two-tier CE relevance gate + multi-part answer hint (eval round 4) (`beeb1b7`)
- **rag**: five retrieval bugs found by the golden-question eval (`ebd232f`)
- **compose**: restore GPU to backend/voice on GB10, pin Live Transcript ASR to CPU (`cb3a280`)

### Performance

- **voice**: move Live Transcript ASR back to GPU (driver 580.159.03 fixed NVML) (`c864fa7`)

### Documentation

- **paper**: camera-ready v4 with updated author list and ajace.com emails (`bc9aa33`)
- add pitch deck PPTX and consolidate collateral into marketing_doc/ (`9360f69`)
- add technical, business, architecture and pitch documents (`17ecfcf`)
- update second author to full name Richard Watson Stephen Amudha (`cea19f9`)
- finalize QASC 2026 camera-ready; keep only the final package (`f52651f`)
- standardize capability brief to US English (`28a065d`)
- add EchoMind AI capability & product brief (`93c5dc4`)
- LNEE LaTeX camera-ready + author reorder (`20faed3`)
- finalize camera-ready author block (`ec4d08f`)
- QASC 2026 camera-ready v3 + response to reviewers (`c1c1fed`)
- add architecture brief v2 (9-page PDF, full feature coverage) (`1584623`)
- add EchoMind architecture brief (3-page PDF) (`58c774d`)
- **readme**: bring README in line with the shipped system (`ec5136b`)

### Other changes

- eval: QASC 2026 paper experiment harness and frozen results (`cbc57d1`)
- Add files via upload (`01b203c`)

## [1.2.0] - 2026-06-27

### Added

- **export**: secure offline export gateway — PII/secret scan + redaction (#5) (`d19177d`)
- **auth**: per-tenant scoping (#4 multi-tenant) (`ef19d68`)
- **silent-assistant**: namespace-aware + always-surface + per-vertical rule packs (#3) (`f75121b`)
- **verticals**: bespoke Meetings, Law, Retail experiences (verticals 3-5/5) (`b9f076e`)
- **verticals**: bespoke Health experience (vertical 2/5) (`9992848`)
- **verticals**: bespoke per-vertical experiences framework + Bank (vertical 1/5) (`0dd5f82`)
- **api**: per-IP rate limiting / quotas, opt-in (#2) (`10a80b3`)
- **docgen**: per-vertical Document Studio templates (`66356f9`)
- **auth**: WebSocket auth gating (Phase 0b, step 5 — hardening) (`bd428f2`)
- **auth**: audit log + usage metering + CORS lock (Phase 0b, step 4) (`ac26d41`)
- **auth**: RBAC + admin user management (Phase 0b, step 3) (`7a83262`)
- **auth**: frontend login gate, opt-in (Phase 0b, step 2) (`d12db42`)
- **auth**: local-accounts + JWT auth core, opt-in via AUTH_ENABLED (Phase 0b, step 1) (`c9bad3d`)
- **packs**: per-vertical theming, content, personas + seeded demo data (UI refurbish) (`c6b834d`)
- **packs**: vertical-pack framework + subdomain wiring (Step 2) (`e8ead2f`)
- **rag**: per-namespace knowledge bases (Step 1: KB namespacing lynchpin) (`2dba137`)
- **voice**: selectable Kokoro voice (7 speakers) in Settings (`4bc0d58`)
- **voice**: selectable TTS engine (Piper or Kokoro-82M) in Settings (`52e6db9`)
- **voice**: accurate final STT via NeMo Parakeet-TDT (fixes domain-term mishearing) (`b6a70d8`)
- **voice**: always keep knowledge base ON (voice RAG-connected by default) (`3afac4a`)
- **llm**: switch to Qwen3-30B-A3B-FP4, cap KV cache, disable reasoning (`bdc12ff`)
- **deploy**: public access via Cloudflare Tunnel for echomind-ajace.com (`7c521f3`)

### Fixed

- **settings**: Settings tab crashed (undefined PERSONA_META for new personas) (`2465767`)
- **voice**: keep barge-in off for the intro's full playback duration (`974b308`)
- **build**: relax huggingface-hub pin 0.33.5 -> >=0.34,<2 (diffusers>=0.38 needs >=0.34) (`421aa46`)
- **voice**: barge-in lead 12->8 (12 was too strict to interrupt); rebuild bakes thinking-off patch (`5088c93`)
- **voice**: raise local reply cap LLM_MAX_TOKENS 220->420 (was truncating answers mid-sentence) (`7b444fe`)
- **voice**: less-aggressive endpointing + stricter barge-in + permissive VAD + CPU Piper (`1c8c923`)

### Performance

- **rag**: cache query embeddings (deterministic, LRU 4096) (`3b6fe19`)

### Documentation

- **db**: Postgres migration runbook (#6 — planned, maintenance-window) (`46bd774`)
- **deploy**: clarify public-hostname step (avoid doubled domain) + troubleshooting (`51bc562`)
- hide generated PPTX (export WIP) — untrack + gitignore, keep PDFs (`daa470c`)
- professional README — accurate stack, modules, product vision, doc links (`c4e6389`)
- add EchoMind Marketing Book + User Guide (PDF & PPTX, with on-device images) (`29fb479`)
- add USER_MANUAL.pdf — styled 56-page PDF of the user manual (`723d34f`)
- add USER_MANUAL.md — complete marketing-style end-to-end user manual (`dfcf300`)
- add CAPABILITIES.md — full capabilities + how-it-works overview (`e59e80d`)

### Build

- **voice**: bake Parakeet into image + run it on CPU (avoids trtllm CUDA-graph crash) (`3a6b1f9`)

### Reverted

- **verticals**: remove bespoke Bank experience (`3ed6c58`)

### Other changes

- Add Document Studio: AI document generation with on-device images + PDF/PPTX export (`2d23f40`)
- Harden security, fix bugs across RAG/transcribe/boardroom/voice, audit prompts (`b08cf25`)
- Implement backchannel and partial transcript features for enhanced voice interaction (`fbbadd0`)
- paper (`539493f`)

## [1.1.0] - 2026-04-29

### Other changes

- Update voice service configurations and enhance TTS handling (`e5292f3`)
- Enhance Docker configurations for offline model preparation and update frontend components (`0818cdc`)
- Comment out Voice Context section in Settings component for future use (`d41014d`)
- Update persona types and enhance voice interaction features (`518fb8e`)
- Add Nemotron ASR adapter, warmup build, voice STT bridge, and Docker context trim (`ddc0aa3`)
- Update Sidebar component to restore navigation items (`1de5063`)
- Enhance ASR model integration and session management (`172b94c`)
- Refactor ASR model integration and update session handling (`d89aeda`)
- Refactor main.py and enhance text normalization in advanced.py and normalize.py (`eaf17a0`)
- Resolve merge conflicts in main.py and package-lock (`34d6847`)
- Resolve stash conflicts after pull (`821f650`)
- Update package-lock.json and Sidebar component (`7f1b818`)
- Enhance Ollama and TensorRT-LLM integration for offline capabilities (`06e788a`)
- Enhance LLM streaming and logging capabilities (`0993588`)
- Enhance project structure and offline capabilities (`1d28247`)
- Refactor Header component and implement chat management features (`07ac10d`)
- Implement chat management features in backend and frontend (`2b9730b`)
- Add Word Cloud feature to Live Transcription (`5d64088`)
- Enhance financial assistant features and session management (`e59fd55`)
- Enhance financial assistant capabilities and improve session management (`95d3512`)
- Enhance TOC index and retrieval features (`5057a30`)
- Enhance TOC index management and data deletion process (`dd037c7`)
- Refactor section indexing and retrieval logic (`22282ae`)
- Refactor section indexing and retrieval enhancements (`0b8b252`)
- Refactor section indexing and retrieval logic (`ace2e4b`)
- Enhance section indexing and retrieval features (`18715c7`)
- Refactor query handling and improve configuration settings (`a988f9b`)
- Enhance query classification and configuration settings (`cfe3360`)
- Refactor document chunking and indexing for improved metadata handling (`03e43d3`)
- Refactor document chunking and indexing for enhanced metadata management (`7abc98c`)
- Refactor document chunking and indexing for improved metadata handling (`045b1b1`)

## [1.0.0] - 2026-02-27

### Other changes

- Enhance WebSocket handling and configuration settings (`595b24b`)
- Add transcript management features and source options handling (`223714c`)
- Enhance transcript time parsing and formatting (`5081ad8`)
- Add time parsing and document metadata handling functions (`5eacb1b`)
- Add sample transcript functionality and enhance metadata storage (`9be8ac5`)
- Detect and docker flow management (`592cb9b`)
- Refactor LLM model integration and enhance performance: Updated LLM model references to `qwen2.5:7b-instruct-q4_K_M` in configuration files and Docker setup. Enabled FAISS GPU support in Docker Compose for improved performance. Adjusted documentation to reflect these changes. (`fa9550e`)
- Update LLM model references and enable FAISS GPU support: Changed LLM model from `qwen2.5:7b-instruct` to `qwen2.5:7b-instruct-q4_K_M` across configuration files, Docker setup, and documentation. Enabled FAISS GPU support in Docker Compose for improved performance. Updated README and other relevant files to reflect these changes. (`5b6ef43`)
- Implement continuous listening mode: Added support for a "listen-only" feature that allows the assistant to respond only after the wake word "EchoMind." Updated relevant components to manage listen buffer text and toggle functionality. Enhanced logging in the server for listen-mode events and adjusted Dockerfile for improved package installation reliability. (`a1fd76b`)
- Enhance wake word functionality: Implemented semantic intent recognition for changing the assistant's wake word, including confirmation prompts. Updated session management to handle wake word changes and improved logging of user interactions. Refactored related tests to ensure proper functionality of wake word change intents. (`e0ca515`)
- Updated ollama loading (`014f1a7`)
- Loading Ollama model (`f6d66b4`)
- Enhance Kyutai STT integration: Implemented pre-loading and warm-up functionality for faster initial connections. Added model download and instance management methods to improve performance and reduce latency during Live Transcript sessions. Updated WebSocket handler to utilize new instance management functions. (`8e92aca`)
- Refactor OrbVisualizer components: Implemented safe radius handling to prevent canvas errors and ensure valid dimensions. Updated OrbCanvas to clamp size values, enhancing robustness. Improved drawing functions in orbEffects to utilize safe radius calculations, ensuring consistent rendering and preventing invalid states during animation. (`d8638d4`)
- Enhance VoiceConversation and VoiceOrb components: Improved VoiceConversation styling for better visual consistency and streamlined VoiceOrb by removing unnecessary state management. Updated TopBar to focus on settings functionality, enhancing overall user experience. (`9015f16`)
- Refactor VoiceConversation and VoiceOrb components: Updated VoiceConversation to streamline boxShadow styling. Simplified VoiceOrb by removing unused state management and status display, enhancing performance and readability. Adjusted TopBar to remove connection status display, focusing on settings functionality. (`fdc69aa`)
- Enhance LiveTranscription component and Docker configurations: Updated LiveTranscription to include mic mute functionality and clear/reset button for improved user interaction. Modified Docker Compose and Dockerfiles to ensure health checks for services and pre-download necessary models during build, optimizing startup time. Updated README to reflect automatic model setup during build. (`5542173`)
- Refactor KnowledgeChat and LiveTranscription components: Updated KnowledgeChat to utilize a custom hook for managing chat state, improving state management and reducing complexity. Enhanced LiveTranscription to accept props for better integration with the app's state, streamlining session handling and user interaction. Added clear chat functionality and improved UI responsiveness. (`7eb6809`)
- Refactor STT streaming and configuration: Enhanced Kyutai STT integration with improved audio processing, including sliding-window VAD and GPU concurrency management. Updated settings for PCM queue backpressure and warmup frames. Improved session handling with audio-relative timestamps and optimized buffer management for efficient transcription. (`5d7dc8f`)
- Update session management and voice interaction features: Enhanced user-specific voice message handling and error recovery. Improved audio processing and added voice activity detection for better transcription accuracy. Updated README and configuration for recent changes, including adjustments to sample rates and dependencies. (`e1f9530`)
- Refactor STT streaming to utilize Kyutai STT exclusively, removing Whisper fallback. Updated README and configuration for Kyutai integration, including sample rate adjustments and improved audio processing. Enhanced session state management for better whitespace normalization and audio handling. Added voice activity detection to reduce noise transcription. Updated Dockerfile and requirements for necessary dependencies. (`bff6cf2`)
- made RAG_QUERY_REWRITE_ENABLED in default false and updated readme.md files (`c821802`)
- Enhance voice interaction capabilities: Improved session management with refined user-specific voice message handling and robust error recovery. Updated UI components for a more intuitive user experience and optimized backend API for efficient transcript storage and retrieval, ensuring seamless voice interaction integration. (`60c2b95`)
- Refine voice interaction features: Improved session management with enhanced user-specific voice message handling and error recovery. Updated UI components for better user experience and optimized backend API for transcript storage and retrieval, ensuring seamless integration with voice interactions. (`8962eeb`)
- Enhance voice conversation features: Introduced dynamic voice message handling with improved session management, including user-specific voice messages and connection error handling. Updated UI components for better user interaction and streamlined context management. Enhanced backend API for transcript storage and retrieval, ensuring better integration with voice interactions. (`633ca12`)
- Refactor voice assistant features: Improved session management by implementing user-specific profiles and conversation memory updates. Enhanced voice command processing for dynamic interactions and streamlined configuration settings for better user experience. (`577edc8`)
- Revamp EchoMind voice assistant: Updated README and HTML to reflect new branding and features, including conversation memory and profile management. Enhanced session handling with rolling memory and user profiles, allowing for dynamic updates via voice commands. Improved configuration settings for memory and assistant defaults. Streamlined conversation context management for better user interaction. (`8a0ea41`)
- Improve error handling in transcript storage: Enhanced the store_transcript_to_db function to include more detailed logging for indexing failures, facilitating better tracking and debugging of transcript-related issues. (`07f0db9`)
- Add logging for transcript indexing errors: Introduced logging to capture warnings when indexing transcripts fails in the store_transcript_to_db function. This enhancement improves error tracking and debugging capabilities in the transcript storage process. (`8c15c96`)
- Refactor configuration and logging for LLM interactions: Updated the settings in config.py to centralize data directory paths and added new paths for transcript handling. Enhanced logging in LLM-related classes to capture full request payloads for better debugging and monitoring. Improved markdown rendering in the frontend to prevent layout issues with nested lists. (`af97302`)
- Enhance transcript handling in intent classification: Updated logic to better identify user requests for transcripts, including new functions for parsing time windows and recent transcripts. Improved retrieval process to filter hits based on user queries related to transcripts, ensuring more accurate responses. Removed unnecessary print statements for cleaner code. (`850fb7e`)
- Add fade-in/fade-out functionality to audio processing: Implemented short fade effects in both frontend and backend audio handling to reduce clicks at chunk boundaries. Updated related functions to enhance audio quality during playback and improved transcript handling in the API for better user experience. (`7d9034c`)
- Refactor voice interaction settings and improve user experience: Updated frontend components to enhance microphone management and knowledge base integration. Adjusted backend API to streamline voice-related requests and improved transcript handling, ensuring a more cohesive interaction flow. (`305e19c`)
- Enhance voice conversation and transcription features: Introduced new settings for voice bot and user names, and added support for knowledge base integration in voice interactions. Updated frontend components to manage microphone state and toggle knowledge base usage. Refactored backend API to handle voice-related requests and improved transcript storage logic, ensuring better integration with the overall system. (`089ecfb`)
- Update voice download functionality: Change Hugging Face base URL to versioned endpoint and improve voice ID parsing logic. Enhance error handling for invalid voice IDs and adjust path formatting for voice files, ensuring compatibility with the new structure. (`e794ea4`)
- Implement voice management features: Added API endpoints for listing installed Piper voices and downloading voices by ID. Enhanced frontend components to support voice selection and downloading, improving user experience. Updated configuration and download script for better voice handling. (`b3253c2`)
- Remove polish feature implementation: Deleted the LLM-based transcript polishing functionality from the backend, including related helper functions and imports. This change reflects the recent refactor to rename polish to refine, streamlining the codebase. (`236cc04`)
- Refactor transcription API and frontend components: Renamed the polish functionality to refine, updating related API routes and frontend services accordingly. Adjusted database schema to reflect changes in text processing terminology, ensuring consistency across the application. Enhanced documentation to clarify the new refined text handling. (`46b5567`)
- changes reverted (`030b8af`)
- Enhance database schema and text processing capabilities: Added a new table for document headings to support structured retrieval and improved text normalization by introducing a function to remove repeated headers and footers. Updated chunking and retrieval logic to utilize these enhancements, ensuring better handling of document structure and user queries. (`40edd92`)
- Integrate text normalization and enhance query handling: Added text normalization in the chunk_document function to improve input consistency. Introduced deterministic query expansion methods to handle typos and TOC queries, enhancing retrieval accuracy. Updated retrieval logic to utilize new query variants and adjusted settings for book retrieval, improving overall query processing and user experience. (`743f182`)
- Enhance database schema and chat functionality: Added a new column for conversation summaries in the chats table and implemented functions to manage conversation summaries during chat interactions. Updated API routes to support summary retrieval and updating, improving the overall chat experience and context management. (`341b0be`)
- Refactor TTS and transcription handling: Improved the TTS voice selection process by optimizing the dynamic voice options in AppSettings. Enhanced the database schema to better manage transcript data with new fields for echotag and echodate. Updated relevant API routes and frontend components to support these changes, further enhancing user interaction and experience. (`b834262`)
- Enhance TTS and transcription features: Introduced Piper TTS voice options and updated AppSettings to support dynamic voice selection. Modified database schema to include echotag and echodate in transcripts. Updated API routes and frontend components to handle new voice and transcription features, improving user experience and flexibility in voice interactions. (`8af2d31`)
- removed unmute in code (`4615895`)
- Update Sidebar component with logo image and add favicon to index.html: Replaced the icon component in the Sidebar with an image logo for better branding. Added a favicon link in index.html to enhance the application's visual identity in browser tabs. (`08745a7`)
- Enhance ConversationStage component with dynamic color resolution: Added functionality to resolve CSS variables for assistant and user orb colors, improving visual consistency. Updated layout to utilize resolved colors and adjusted orb visualizer glow behavior for better user feedback during interactions. (`8d01ea0`)
- Enhance ConversationStage and orb visualizer for better user interaction: Improved the layout and visual feedback of the ConversationStage component, ensuring consistent orb states during voice interactions. Updated styling for action buttons and context input to enhance overall user experience. (`466cd34`)
- Refactor ConversationStage and orb visualizer for improved user feedback: Updated the ConversationStage component to enhance context management and visual feedback during voice interactions. Adjusted orb visualizer behavior to maintain consistent visual states for idle and listening, ensuring a smoother user experience. Improved styling and layout for context input and action buttons. (`925b3ff`)
- Implement markdown stripping for TTS and enhance conversation state management: Added a new function to remove markdown from text inputs, ensuring cleaner output for TTS and LLM. Updated various components to utilize this function, improving the clarity of spoken responses and user inputs. Refactored the ConversationStage and VoiceConversation components to streamline state management and remove demo controls, enhancing overall user experience during voice interactions. (`9880a87`)
- Refactor ConversationStage layout and improve voice connection state management: Adjusted the layout of orbs in the ConversationStage component to maintain consistent sizing and prevent layout shifts. Updated voice connection logic to enhance state transitions and added hysteresis for microphone state changes, improving user experience during voice interactions. (`b07e2cc`)
- Refactor TTS greeting and streamline intro tip handling: Updated the TTS introductory phrase for improved engagement and removed the intro tip from the conversation state, enhancing the user experience during session initiation. (`f024bc9`)
- Enhance frontend configuration for HTTPS support: Updated docker-compose to expose port 3443 for HTTPS, modified nginx configuration to handle both HTTP and HTTPS with a self-signed certificate, and adjusted Vite configuration to enable HTTPS in development. Updated README to reflect new access URLs and instructions for using HTTPS. (`c189bbb`)
- Update introductory phrase for TTS and remove intro tip from state: Changed the greeting phrase for TTS to a more engaging version and eliminated the intro tip from the conversation state, streamlining the user experience during session initiation. (`9755130`)
- Refactor intro tip handling and update greeting phrase: Removed the intro tip display from the UI and adjusted voice connection state management to eliminate its dependency. Updated the introductory phrase for TTS to provide a more engaging greeting for users at the start of the session. (`ce072b7`)
- Update voice connection state management and reposition intro tip: Changed userOrb state to "listening" and refined assistantOrb states for "speaking" and "idle" during voice events. Moved the intro tip display below the orbs for better visibility and adjusted its styling for improved user experience. (`65210b2`)
- Add barge-in speech lead settings and intro TTS feature: Introduced new configuration options for consecutive speech frames required for barge-in detection, enhancing robustness against false triggers. Added an introductory phrase feature that prompts users to unmute and speak upon connection, improving user experience during initial interactions. (`65e01ec`)
- Enhance LiveTranscription component with improved UI and feedback: Updated the LiveTranscription interface to visually indicate listening status with dynamic styles and animations. Added new animations for the listening state and adjusted button styles for better user interaction. Introduced a moving gradient effect for the orb visualizer to enhance visual feedback during audio processing. (`0f132fe`)
- Enhance WebSocket handling and add transcript tagging feature: Improved WebSocket connection management in LiveTranscription component, including error handling and status updates. Introduced a new API endpoint for previewing transcript tags and conversation types, along with corresponding frontend integration for fetching and displaying tags. Updated Vite configuration to support WebSocket connections in the proxy settings. (`fd2a3ea`)
- Add storage usage endpoint and integrate with sidebar: Implemented a new API endpoint to retrieve vector DB storage usage and disk capacity. Updated the frontend to display this information in the sidebar, enhancing user awareness of storage metrics. Added automatic refresh functionality for real-time updates. (`3a053b1`)
- Refactor source chunk handling in FaissIndex: Updated the source_by_chunk mapping to improve data organization and retrieval efficiency. This change enhances the clarity of source data associated with chunk IDs, ensuring better management of metadata during indexing. (`bd488be`)
- Refactor assistant message rendering and loading indication: Improved the Markdown rendering for assistant messages, enhancing visual clarity and formatting. Updated loading indicators to provide a better user experience during message processing. (`5e39015`)
- Implement Markdown rendering for assistant messages in KnowledgeChat: Added a styled Markdown renderer to enhance the display of assistant responses, including support for headings, lists, and code formatting. Improved loading indication for assistant messages while processing. This update enhances the user experience by providing clearer and more visually appealing message formatting. (`6869e91`)
- Enhance RAG system with source exposure configuration and context handling: Added a new setting to control citation exposure to clients. Refactored context building logic to avoid source lines in responses, ensuring internal grounding only. Improved error handling and logging for RAG answer generation, enhancing overall stability and audit capabilities. (`ad36bd6`)
- Update embedding configuration and truncation logic: Adjusted the default maximum characters for embeddings to 2000 for better compatibility with 512-token models. Added a safeguard in the truncation function to ensure the limit is not set to zero, enhancing stability in text processing. (`a1df52a`)
- Add embedding truncation logic and configuration for max characters: Introduced a new method to truncate text for embedding API calls, ensuring input length constraints are respected. Updated configuration to allow setting a maximum character limit for embeddings, enhancing stability and performance during text processing. (`de079b4`)
- Refactor document addition process in FaissIndex: Updated the add_document method to utilize a new chunking approach, improving text extraction and embedding handling. Enhanced database insertion logic for chunks and documents, ensuring better data integrity and organization. (`cbc69aa`)
- Refactor sparse indexing call in retrieve function: Changed the sparse search method to a synchronous call for improved performance and consistency in the retrieval process. (`734a368`)
- Add support for document deletion and integrate sparse indexing: Implemented a new API endpoint for deleting documents, enhancing the backend to remove associated data from both FAISS and sparse indices. Updated frontend components to allow users to delete documents from the knowledge base, improving overall data management and user experience. (`4d17f39`)
- Refactor LiveTranscription and UI components for improved layout and responsiveness: Enhanced the structure of the LiveTranscription component, adjusting styles for better visual hierarchy and overflow handling. Updated orb visualizer parameters and UI elements for consistent design across components, including adjustments to color schemes and spacing for a more cohesive user experience. (`86e700f`)
- Refactor orb visualizer parameters and drawing logic: Adjusted glow intensity, pulse behavior, and wave ring rendering for improved visual effects. Enhanced responsiveness of particle orbiting based on state, optimizing performance and aesthetics during voice interactions. (`b384141`)
- Enhance voice conversation functionality: Added a new WebSocket URL for voice conversations and integrated voice connection hooks in the VoiceConversation component. Improved UI structure and state management for real-time interactions. (`ddbcd1f`)
- Add document listing and general conversation handling: Introduced a new API endpoint `/docs/list` to retrieve uploaded documents. Enhanced the RAG system to identify general conversation and respond appropriately without citations. Updated frontend components to support document listing and improved user experience during uploads. (`413aecd`)
- Implement streaming chat functionality in backend and frontend: Added `chat_stream` method to `OpenAICompatChat` for token-by-token response streaming. Updated `answer_stream` in `advanced.py` to yield response chunks. Enhanced FastAPI route with `/ask-stream` for streaming responses. Modified frontend to utilize `askChatStream` for real-time message updates during chat interactions. (`da4787d`)
- Fix import path in kb.py to ensure correct module referencing. (`3513f43`)
- Update scipy version constraints in requirements files for compatibility with aarch64 architecture. Adjusted to allow pip to select a suitable wheel version, avoiding the need for building from source. (`c751d79`)
- Refactor backend configuration and transcription modules: Simplify settings for database and file paths, enhance session state management for real-time transcription, and improve knowledge base interaction. Update tagging and polishing logic for better metadata extraction and transcript formatting. (`4dfa4f8`)
- Refactor LiveTranscription component to use full transcript state instead of entries array. Update WebSocket handling for improved transcript management and display. Enhance Dockerfile and requirements for GPU support with FAISS. Update README with GPU usage instructions and environment variable configurations for better flexibility. (`f843777`)
- Enhance frontend configuration and components: Added WebSocket path handling, improved API proxy settings, updated transcript entry types, and introduced new Wave icon. Updated Nginx configuration for better proxy handling. (`e20ccc6`)
- Update voice TTS Piper adapter (`2c9df0c`)
- Implement initial project structure for EchoMind Enterprise, including backend, frontend, voice integration, and docker-compose setup. (`160f786`)

