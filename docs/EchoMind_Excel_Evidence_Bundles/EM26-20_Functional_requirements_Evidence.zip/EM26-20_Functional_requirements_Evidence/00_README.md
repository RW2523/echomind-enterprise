# EM26-20 — Functional requirements: evidence

39 functional requirements (5 from 2025) with source, review, delivery commit, first version, test and release; requirement changes.

Open `EM26-20_Functional_Requirements.xlsx` (the register) and `00_Document_List_EM26-20.xlsx` (every cited document, the sheet that cites it and where it is in this zip).

Public copy — clients appear as Client A–D; the 2025 originals (which name the 2025 customer) are held in the controlled copy and listed in the document list.

| Folder | Files |
|---|---|
| `01_Review_Records` | 15 |
| `03_QMS_Documents` | 7 |
| `04_Approvals_Releases_and_Versions` | 6 |
| `05_Evidence_Pack_Documents` | 2 |
| `06_Commits` | 69 |
| `07_Tests_and_Evaluation` | 16 |
| `08_Tickets_and_CI_Runs` | 1 |
| `09_Source_and_Configuration` | 3 |

Not held (listed in the document list): 3.
