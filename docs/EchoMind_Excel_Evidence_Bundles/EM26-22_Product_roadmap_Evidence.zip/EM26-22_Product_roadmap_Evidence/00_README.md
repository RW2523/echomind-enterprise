# EM26-22 — Product roadmap: evidence

Timeline May 2025 → Jun 2027, the 2025 plan against what happened, the six 2026 versions, and the forward plan with owners and dates.

Open `EM26-22_Product_Roadmap.xlsx` (the register) and `00_Document_List_EM26-22.xlsx` (every cited document, the sheet that cites it and where it is in this zip).

Public copy — clients appear as Client A–D; the 2025 originals (which name the 2025 customer) are held in the controlled copy and listed in the document list.

| Folder | Files |
|---|---|
| `01_Review_Records` | 23 |
| `03_QMS_Documents` | 9 |
| `04_Approvals_Releases_and_Versions` | 8 |
| `05_Evidence_Pack_Documents` | 6 |
| `06_Commits` | 53 |
| `07_Tests_and_Evaluation` | 8 |
| `08_Tickets_and_CI_Runs` | 1 |
| `09_Source_and_Configuration` | 1 |

Not held (listed in the document list): 3.
