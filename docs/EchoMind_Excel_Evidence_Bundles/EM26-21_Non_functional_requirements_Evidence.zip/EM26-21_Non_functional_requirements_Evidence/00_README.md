# EM26-21 — Non-functional requirements: evidence

31 NFRs with origin, approved target and monitoring; 9 from 2025; every recorded measurement (golden suite, research harness, acceptance runs, CI).

Open `EM26-21_Non_Functional_Requirements.xlsx` (the register) and `00_Document_List_EM26-21.xlsx` (every cited document, the sheet that cites it and where it is in this zip).

Public copy — clients appear as Client A–D; the 2025 originals (which name the 2025 customer) are held in the controlled copy and listed in the document list.

| Folder | Files |
|---|---|
| `01_Review_Records` | 12 |
| `03_QMS_Documents` | 11 |
| `04_Approvals_Releases_and_Versions` | 8 |
| `05_Evidence_Pack_Documents` | 1 |
| `06_Commits` | 32 |
| `07_Tests_and_Evaluation` | 57 |
| `08_Tickets_and_CI_Runs` | 4 |
| `09_Source_and_Configuration` | 2 |

Not held (listed in the document list): 2.
