EchoMind — QASC 2026 camera-ready (Springer LNEE / svproc, single column, A4, 10pt)
Files: main.tex (manuscript), svproc.cls (Springer proceedings class v1.3), fig1_v2.pdf (Figure 1).
Build: pdflatex main ; pdflatex main   (second pass resolves cross-references).
References are inline (thebibliography); no bibtex step. A4 forced after \mainmatter.
