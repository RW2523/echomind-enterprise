Evidence for surveillance audit 2026-10-14, finding 6 (Opp for imp, ISO 9001:2015 clause 6.1.1) - AJACE Inc., EchoMind Product

00_Findings_Sheet_Row_6.xlsx
    Completed sheet row: columns A to T, auditee columns J to N filled
01_Response_to_Finding_6.docx
    Response J to M with the evidence list (approved AR-2026-008)
02_EM26-35_AI_Impact_Assessment_EchoMind.docx
    The AI impact assessment (column L)
03_SOP-05_Design_and_Development_Control_rev1.2.docx
    Procedure revised: section 7a AI impact assessment (column J)
04_REG-03_Risk_Register_R-15_to_R-18.docx
    AI risks R-15 to R-18 and opportunity O-05 (column J and L)
05_REG-04_CAPA_Log_OFI-2026-06.docx
    Finding logged, section D, OFI-2026-06 (columns K to N)
06_AR-2026-008_Approval_Record.docx
    Approval of the above on 20-Oct-26 (column N)

Controlled source: github.com/RW2523/echomind-enterprise, docs/qms/. Word copies are uncontrolled when printed.
